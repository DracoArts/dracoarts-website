import Banner from "@/components/terms/Banner";
import Terms from "@/components/terms/Terms";

const page = () => {
  return (
    <>
      <Banner />
      <Terms />
    </>
  );
};

export default page;
