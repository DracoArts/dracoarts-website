import Banner from "@/components/cart/Banner";
import Cart from "@/components/cart/Cart";

const page = () => {
  return (
    <>
      <Banner />
      <Cart />
    </>
  );
};

export default page;
